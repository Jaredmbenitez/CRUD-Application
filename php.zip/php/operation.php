<?php 
require_once("db.php");
require_once("functions.php");

$con = createDB();

if (isset($_POST['create'])){

	createData();

}


function createData(){
	$username = textboxValue('Username');
	$BTC = textboxValue('BTC');
	$ETH = textboxValue('ETH');/*$ETH =(isset($_POST['ETH']) ? $_POST['ETH'] : '');*/
	$DASH = textboxValue('DASH');

	if($username && $BTC && $ETH && $DASH){
		$sql = "INSERT INTO cryptoholdings(username,BTC_holdings,ETH_holdings,DASH_holdings)
		VALUES('$username','$BTC','$ETH','$DASH')";
		if($GLOBALS['con']->query($sql)){	        /*(mysqli_query($GLOBALS['con'],$sql))*/
			$GLOBALS['con']->commit();
			echo "Record Successfully inserted...!". (mysqli_error($GLOBALS['con'])) ;		
		}
		else{
			echo "Error Recording Data <br>" . mysqli_error($GLOBALS['con']);
		}
	}
	else{echo "Provide all data in textboxes.";

	}


}

function textboxValue($value){
	$textbox = mysqli_real_escape_string($GLOBALS['con'],trim($_POST[$value]));
	if(empty($textbox)){
		return false;
	}
	else{
		return $textbox;
	}



}
?>