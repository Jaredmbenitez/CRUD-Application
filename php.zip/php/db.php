<?php
function createDB(){

	$servername='localhost';
	$username='root';
	$password='password';
	$dbname='holdings';
	//create connection to our database "holdings"
	$con= new mysqli($servername,$username,$password,$dbname);

	if(!$con){
		die("Connection Failed: ". mysqli_connect_error());
	}
	//create Database
	$sql= 'CREATE DATABASE IF NOT EXISTS $dbname';

	if(mysqli_query($con,$sql)){
		$con = mysqli_connect($servername,$username,$password,$dbname);

		$sql= 'CREATE TABLE IF NOT EXISTS cryptoholdings(
			username VARCHAR(10) NOT NULL,
			BTC_holdings FLOAT(11) NOT NULL,
			ETH_holdings FLOAT(11) NOT NULL,
			DASH_holdings FLOAT(11) NOT NULL)';
		if(mysqli_query($con,$sql)){
			return $con;}
		else{
			echo "Error In Create Query".   mysqli_error($GLOBALS['con']);
		}
		

	}
	else{
		echo "Error while creating Database...". mysqli_error($con);
	}
}


?>